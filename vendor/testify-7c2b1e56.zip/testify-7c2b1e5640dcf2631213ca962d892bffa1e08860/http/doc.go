//  A set of tools to make testing http activity using the Go testing system easier.
package http
